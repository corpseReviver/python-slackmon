# slackmon
A Slack channel message retriever
